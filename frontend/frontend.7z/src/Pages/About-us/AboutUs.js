function AboutUs() {
    return (
        <div className="center">
            <h1>About Us</h1>
            <p>We are a group of 4 dedicated to the art of recipe building!
                <br />
                If for any reason you need to contact us, please email us at: <a href="mailto:fective@recipebuilder.com">Recipe Builder Team Email</a>
            </p>
        </div >
    );
}

export default AboutUs;
